# hand-note-strings

Play strings of music notes in mid-air. A webcam tracks your hand in
[TouchDesigner](https://derivative.ca/) (via the MediaPipe plugin), and this
repo turns the hand data into notes you can hear, send as MIDI, or draw.

The musical logic is plain Python with no dependencies and is unit-tested
outside TouchDesigner; the TouchDesigner side is a thin layer of Script CHOP
callbacks.

> **Status:** the Python core is tested (26 tests). The TouchDesigner wiring
> follows the plugin's documented channel names but has not been run inside
> TouchDesigner yet. See [`touchdesigner/README.md`](touchdesigner/README.md) for the
> short list of things to confirm first.

## How it plays

| Gesture | Result |
| --- | --- |
| Pinch thumb and index finger | Starts a note |
| Hand position, left to right | Pitch, snapped to a scale (default: C minor pentatonic) |
| Hand height | Velocity (higher is louder) |
| Keep pinching and drag sideways | Glissando: each new scale step is a new note |
| Open your hand (or leave the frame) | Note off |

Every note is added to the **string**, a rolling history of the last 32 notes
(position, pitch, velocity, duration) that you can render as a line of beads,
export as JSON, or feed to generative visuals.

## Inspiration

Hand-tracking overlay on a webcam feed, seen in an Instagram reel by
[@sonicdeadhorse](https://www.instagram.com/sonicdeadhorse/)
(caption in Chinese, truncated in the screenshot, mentions practising in the air with the fingers).
The screenshot is in [`assets/reference/`](assets/reference/inspiration-screenshot.png)
as a visual reference only. It is someone else's content, so remove it before
making this repo public.

## Layout

```
src/handnotes/          pure-Python core (stdlib only, Python 3.9+)
  scales.py             scales, MIDI note -> Hz / name
  mapping.py            hand x -> quantised pitch (with hysteresis), y -> velocity
  triggers.py           pinch trigger with hysteresis
  engine.py             HandFrame in -> note on/off events out
  note_string.py        rolling note history, CHOP-ready columns, JSON export
  adapters.py           MediaPipe plugin channels (h1:thumb_tip:x ...) -> HandFrame
  session.py            shared engine so several Script CHOPs can use it
touchdesigner/          Script CHOP callbacks + setup guide (put handnotes.toe here)
tools/simulate.py       run the engine on a fake hand, no TouchDesigner needed
tests/                  pytest suite
```

## Quick start

```bash
pip install -e ".[dev]"
pytest -q
python tools/simulate.py            # prints note events for a synthetic hand
python tools/simulate.py --scale major --low 60 --high 72 --json
```

Then follow [`touchdesigner/README.md`](touchdesigner/README.md) to hook up the webcam.

## Tuning

Defaults live in `handnotes.session.configure(...)` (uncomment the call in
`touchdesigner/note_engine_callbacks.py`):

- `scale`, `root`, `low`, `high`: which notes are on the keyboard (`minor_pentatonic`, `major`, `dorian`, `blues`, `chromatic`, ...)
- `pinch_on` / `pinch_off`: pinch ratio thresholds. The ratio is thumb-index distance divided by palm length, so it works at any distance from the camera. Lower `pinch_on` if notes trigger too easily.
- `hysteresis`: how sticky a note is near a zone edge (fraction of one note-width)
- `glide`: set `False` to make a pinch play exactly one note
- `max_notes`: length of the string

## Roadmap

- [ ] Harp mode: fingertips pluck notes by crossing horizontal "strings" (the ruler line in the reference video)
- [ ] Per-finger polyphony using all five fingertips
- [ ] Second hand: octave / scale switching
- [ ] Export the string as a `.mid` file
- [ ] Script that builds the TouchDesigner network (so the project is diffable, not just a binary `.toe`)

## License

MIT. See [LICENSE](LICENSE).
